﻿namespace WebAPI.Dto
{
    public class trackDto
    {
        public trackDto(string title_track)
        {
            Title_track = title_track;
        }

        public string Title_track { get; set; }
    }
}
