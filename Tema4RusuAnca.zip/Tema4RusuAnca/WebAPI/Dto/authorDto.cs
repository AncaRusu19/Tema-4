﻿namespace WebAPI.Dto
{
    public class authorDto
    {
        public authorDto(string name)
        {
            Name = name;
        }

        public string Name { get; set; }
    }
}
